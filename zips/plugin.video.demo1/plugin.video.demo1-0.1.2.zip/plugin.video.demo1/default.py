import sys
import xbmcgui
import xbmcplugin
import urllib
import urlparse

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
xbmcplugin.setContent(addon_handle, 'movies')

print base_url
print addon_handle
print args

xbmcplugin.setContent(addon_handle, 'movies')

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)

print "kodidev"
print mode

if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'Folder One'})
    li = xbmcgui.ListItem('Folder One', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    print url
    url = build_url({'mode': 'folder', 'foldername': 'Folder Two'})
    li = xbmcgui.ListItem('Folder Two', iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li, isFolder=True)
    print url
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'folder':
    print "folder loop"
    foldername = args['foldername'][0]
    print foldername
    url = 'http://www.vidsplay.com/wp-content/uploads/2017/04/alligator.mp4'
    li = xbmcgui.ListItem(foldername + ' Video', iconImage='DefaultVideo.png')
    print li
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    print url
    xbmcplugin.endOfDirectory(addon_handle)

