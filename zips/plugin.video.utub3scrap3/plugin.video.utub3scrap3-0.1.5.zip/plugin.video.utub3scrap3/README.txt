#forthelulz

complete detailed tutorial here 

http://www.desinerd.co.in/python-how-to-take-user-input-kodi/

